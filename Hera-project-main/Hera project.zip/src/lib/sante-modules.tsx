import { Activity, Apple, Moon, Brain, BookOpen, Repeat } from "lucide-react";

export type ModuleId = "physique" | "nutrition" | "sommeil" | "mentale" | "journal" | "habitudes";

export const MODULES: Array<{
  id: ModuleId;
  category: string;
  title: string;
  bg: string;
  accent: string;
  icon: React.ComponentType<React.SVGProps<SVGSVGElement>>;
  summary: string;
  tagline: string;
}> = [
  {
    id: "physique",
    category: "Physique",
    title: "Activité",
    bg: "bg-rose/40 border-rose",
    accent: "bg-rose/60",
    icon: Activity,
    summary: "5 230 pas · 312 kcal",
    tagline: "Suivez votre énergie au quotidien.",
  },
  {
    id: "sommeil",
    category: "Repos",
    title: "Sommeil",
    bg: "bg-sky-pastel/50 border-sky-pastel",
    accent: "bg-sky-pastel/70",
    icon: Moon,
    summary: "7h 24m · Qualité 84%",
    tagline: "La qualité de vos nuits, en détail.",
  },
  {
    id: "nutrition",
    category: "Alimentation",
    title: "Nutrition",
    bg: "bg-mint/40 border-mint",
    accent: "bg-mint/60",
    icon: Apple,
    summary: "Équilibre stable · 1.2L",
    tagline: "Hydratation, repas, équilibre.",
  },
  {
    id: "mentale",
    category: "Bien-être",
    title: "Santé mentale",
    bg: "bg-lavender/40 border-lavender",
    accent: "bg-lavender/60",
    icon: Brain,
    summary: "Stress faible · Humeur ✦",
    tagline: "Une parenthèse pour vous écouter.",
  },
  {
    id: "journal",
    category: "Réflexion",
    title: "Journal",
    bg: "bg-card border-border",
    accent: "bg-muted",
    icon: BookOpen,
    summary: "3 entrées cette semaine",
    tagline: "Couchez vos pensées sur le papier.",
  },
  {
    id: "habitudes",
    category: "Routine",
    title: "Habitudes",
    bg: "bg-card border-border",
    accent: "bg-muted",
    icon: Repeat,
    summary: "4 séries actives",
    tagline: "Cultivez vos rituels jour après jour.",
  },
];

export const getModule = (id: string) => MODULES.find((m) => m.id === id);
