import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ChevronLeft, RefreshCw } from "lucide-react";
import { clearProfile, loadProfile } from "@/lib/profile";
import { useEffect, useState } from "react";

export const Route = createFileRoute("/_app/profil")({
  head: () => ({
    meta: [
      { title: "Profil — Sereine" },
      { name: "description", content: "Vos informations et préférences." },
    ],
  }),
  component: ProfilPage,
});

function ProfilPage() {
  const navigate = useNavigate();
  const [profile, setProfile] = useState(loadProfile);
  useEffect(() => setProfile(loadProfile()), []);

  const sections = [
    {
      label: "Informations personnelles",
      hint: profile
        ? `${profile.prenom}${profile.age ? `, ${profile.age} ans` : ""}`
        : "—",
    },
    {
      label: "Objectifs",
      hint: profile ? `${profile.goals.length} objectifs actifs` : "—",
    },
    { label: "Statistiques", hint: "Tendances & progression" },
    { label: "Thèmes & couleurs", hint: "Pastel · Clay" },
    { label: "Notifications", hint: "Personnaliser" },
    { label: "Confidentialité", hint: "Vos données" },
  ];

  return (
    <div className="px-6 pt-12">
      <Link
        to="/"
        className="inline-flex items-center gap-1 text-sm text-muted-foreground mb-6 hover:text-foreground"
      >
        <ChevronLeft className="size-4" /> Retour
      </Link>

      <header className="mb-8">
        <h1 className="font-serif-italic text-3xl">Profil</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Personnalisez votre expérience
        </p>
      </header>

      <div className="space-y-4">
        {sections.map((s) => (
          <button
            key={s.label}
            className="w-full text-left p-5 bg-card border border-border rounded-3xl flex justify-between items-center hover:border-clay/40 transition-colors"
          >
            <div>
              <p className="text-sm font-medium">{s.label}</p>
              <p className="text-xs text-muted-foreground mt-0.5">{s.hint}</p>
            </div>
            <span className="text-muted-foreground">›</span>
          </button>
        ))}

        <button
          onClick={() => {
            clearProfile();
            navigate({ to: "/onboarding" });
          }}
          className="w-full mt-2 p-5 bg-card border border-dashed border-border rounded-3xl flex items-center gap-3 text-sm text-muted-foreground hover:text-foreground hover:border-clay/40 transition-colors"
        >
          <RefreshCw className="size-4" /> Refaire l'onboarding
        </button>
      </div>
    </div>
  );
}
